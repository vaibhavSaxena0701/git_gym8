import React from 'react'
import '../../assests/css/style/hiit.css'

function Hiit() {
  return (
    <>
    <h1>vaibhav</h1>

    
    
    
    </>
  )
}

export default Hiit